const API = "http://localhost:8081/contacts";

let editId = null;

// Load contacts when page opens
window.onload = function () {
    loadContacts();
};

// Save or Update Contact
function saveContact() {

    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;

    if(name==="" || phone==="" || email===""){
        alert("Please fill all fields");
        return;
    }

    const contact = {
        name:name,
        phone:phone,
        email:email
    };

    if(editId==null){

        fetch(API,{
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(contact)
        })
        .then(res=>res.json())
        .then(()=>{
            clearForm();
            loadContacts();
            alert("Contact Saved Successfully");
        });

    }else{

        fetch(API+"/"+editId,{
            method:"PUT",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(contact)
        })
        .then(res=>res.json())
        .then(()=>{
            editId=null;
            document.querySelector(".btn-success").innerHTML="Save Contact";
            clearForm();
            loadContacts();
            alert("Contact Updated Successfully");
        });

    }

}

// Display Contacts
function loadContacts(){

fetch(API)
.then(res=>res.json())
.then(data=>{

let rows="";

data.forEach(contact=>{

rows+=`
<tr>

<td>${contact.id}</td>
<td>${contact.name}</td>
<td>${contact.phone}</td>
<td>${contact.email}</td>

<td>
<button class="btn btn-warning btn-sm"
onclick="editContact(${contact.id})">
Edit
</button>
</td>

<td>
<button class="btn btn-danger btn-sm"
onclick="deleteContact(${contact.id})">
Delete
</button>
</td>

</tr>
`;

});

document.getElementById("tableBody").innerHTML=rows;

});

}

// Edit Contact
function editContact(id){

fetch(API+"/"+id)
.then(res=>res.json())
.then(contact=>{

editId=id;

document.getElementById("name").value=contact.name;
document.getElementById("phone").value=contact.phone;
document.getElementById("email").value=contact.email;

document.querySelector(".btn-success").innerHTML="Update Contact";

});

}

// Delete Contact
function deleteContact(id){

if(confirm("Delete this contact?")){

fetch(API+"/"+id,{
method:"DELETE"
})
.then(()=>{
loadContacts();
alert("Contact Deleted Successfully");
});

}

}

// Search Contact
function searchContact(){

const keyword=document.getElementById("search").value;

if(keyword===""){
loadContacts();
return;
}

fetch(API+"/search?name="+keyword)
.then(res=>res.json())
.then(data=>{

let rows="";

data.forEach(contact=>{

rows+=`

<tr>

<td>${contact.id}</td>

<td>${contact.name}</td>

<td>${contact.phone}</td>

<td>${contact.email}</td>

<td>

<button class="btn btn-warning btn-sm"
onclick="editContact(${contact.id})">

Edit

</button>

</td>

<td>

<button class="btn btn-danger btn-sm"
onclick="deleteContact(${contact.id})">

Delete

</button>

</td>

</tr>

`;

});

document.getElementById("tableBody").innerHTML=rows;

});

}

// Clear Form
function clearForm(){

document.getElementById("name").value="";
document.getElementById("phone").value="";
document.getElementById("email").value="";

}