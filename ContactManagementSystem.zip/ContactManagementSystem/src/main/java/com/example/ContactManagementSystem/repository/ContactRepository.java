package com.example.ContactManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ContactManagementSystem.model.Contact;

public interface ContactRepository extends JpaRepository<Contact, Long>{

    List<Contact> findByNameContainingIgnoreCase(String name);

}
