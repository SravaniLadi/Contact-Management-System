package com.example.ContactManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.ContactManagementSystem.model.Contact;
import com.example.ContactManagementSystem.service.ContactService;

@RestController
@RequestMapping("/contacts")
@CrossOrigin("*")
public class ContactController {

    @Autowired
    private ContactService service;

    // View All Contacts
    @GetMapping
    public List<Contact> getAllContacts() {
        return service.getAllContacts();
    }

    // Search Contact
    @GetMapping("/search")
    public List<Contact> searchContact(@RequestParam String name) {
        return service.searchContact(name);
    }

    // Save Contact
    @PostMapping
    public Contact saveContact(@RequestBody Contact contact) {
        return service.saveContact(contact);
    }

    // Get Contact by ID
    @GetMapping("/{id}")
    public Contact getContact(@PathVariable Long id) {
        return service.getContactById(id);
    }

    // Update Contact
    @PutMapping("/{id}")
    public Contact updateContact(@PathVariable Long id,
                                 @RequestBody Contact contact) {
        return service.updateContact(id, contact);
    }

    // Delete Contact
    @DeleteMapping("/{id}")
    public void deleteContact(@PathVariable Long id) {
        service.deleteContact(id);
    }

}