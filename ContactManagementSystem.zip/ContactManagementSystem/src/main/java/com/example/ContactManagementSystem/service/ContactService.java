package com.example.ContactManagementSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ContactManagementSystem.model.Contact;
import com.example.ContactManagementSystem.repository.ContactRepository;

@Service
public class ContactService {

    @Autowired
    private ContactRepository repository;

    // Save Contact
    public Contact saveContact(Contact contact) {
        return repository.save(contact);
    }

    // View All Contacts
    public List<Contact> getAllContacts() {
        return repository.findAll();
    }

    // Search Contact
    public List<Contact> searchContact(String name) {
        return repository.findByNameContainingIgnoreCase(name);
    }

    // Get Contact by ID
    public Contact getContactById(Long id) {
        Optional<Contact> contact = repository.findById(id);
        return contact.orElse(null);
    }

    // Update Contact
    public Contact updateContact(Long id, Contact updatedContact) {

        Contact contact = repository.findById(id).orElse(null);

        if (contact != null) {
            contact.setName(updatedContact.getName());
            contact.setPhone(updatedContact.getPhone());
            contact.setEmail(updatedContact.getEmail());
            return repository.save(contact);
        }

        return null;
    }

    // Delete Contact
    public void deleteContact(Long id) {
        repository.deleteById(id);
    }

}